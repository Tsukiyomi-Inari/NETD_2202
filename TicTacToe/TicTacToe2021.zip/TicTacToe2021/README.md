# TicTacToe2021
Demo to be used for Class Exercise 3 as a part of NETD 2021
